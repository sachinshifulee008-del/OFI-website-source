// Next.js instrumentation hook — runs once per server boot (dev and prod).
// If the investigation database is empty (fresh provisioning, recycled
// sandbox, schema-only db push), restore the verified corpus automatically
// so the AI and every view always have data to work with.
export async function register() {
  if (process.env.NEXT_RUNTIME !== "nodejs") return;
  try {
    const { seedIfEmpty } = await import("@/lib/ofi/seedRunner");
    const seeded = await seedIfEmpty();
    if (!seeded) console.log("[ofi] corpus present — no auto-seed needed.");
  } catch (e) {
    console.error("[ofi] startup auto-seed failed:", e);
  }
}
