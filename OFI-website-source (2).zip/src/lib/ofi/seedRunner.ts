import { db } from "@/lib/db";
import { SEED_RECORDS } from "./seedData";

export async function seedDatabase(): Promise<number> {
  await db.source.deleteMany();
  await db.investigation.deleteMany();

  for (const r of SEED_RECORDS) {
    const rec = await db.investigation.create({
      data: {
        code: r.code,
        name: r.name,
        category: r.category,
        objective: r.objective,
        summary: r.summary,
        gravityCondition: r.gravityCondition,
        facility: r.facility,
        platform: r.platform,
        status: r.status,
        launchYear: r.launchYear ?? null,
        delivery: r.delivery ?? null,
        researchAreas: JSON.stringify(r.researchAreas),
        fuelsMaterials: JSON.stringify(r.fuelsMaterials),
        keyFindings: JSON.stringify(r.keyFindings),
        variables: JSON.stringify(r.variables),
        doi: r.doi ?? null,
        sourceUrl: r.sourceUrl ?? null,
        ntrsUrl: r.ntrsUrl ?? null,
        datasetAvailable: r.datasetAvailable,
        measurementData: r.measurementData,
      },
    });
    for (const s of r.sources) {
      await db.source.create({
        data: {
          investigationId: rec.id,
          title: s.title,
          authors: s.authors,
          year: s.year ?? null,
          venue: s.venue,
          kind: s.kind,
          doi: s.doi ?? null,
          url: s.url ?? null,
        },
      });
    }
  }
  return SEED_RECORDS.length;
}

// Self-healing: if the database boots empty (fresh provisioning, recycled
// sandbox, or a schema-only db push), restore the verified corpus at startup.
export async function seedIfEmpty(): Promise<boolean> {
  const count = await db.investigation.count();
  if (count > 0) return false;
  const seeded = await seedDatabase();
  console.log(`[ofi] empty database detected at startup — seeded ${seeded} investigations.`);
  return true;
}
