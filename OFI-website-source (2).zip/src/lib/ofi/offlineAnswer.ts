// Deterministic tutor-style answers composed ONLY from verified corpus record
// fields. Used when the LLM service is unavailable — the user always gets a
// proper, readable answer; every statement traces to a cited record.
import type { InvestigationDTO } from "./types";

function trimSentences(text: string, maxSentences = 2): string {
  const sentences = text.replace(/\s+/g, " ").trim().split(/(?<=[.!?])\s+/);
  const kept = sentences.slice(0, maxSentences).join(" ");
  return kept.length > 0 ? kept : text.trim();
}

function lessonBlock(inv: InvestigationDTO): string {
  const lines: string[] = [];
  lines.push(`**${inv.code} — ${inv.name}**`);
  lines.push(`- **What it studied:** ${inv.objective}`);
  lines.push(
    `- **Where and how:** ${inv.facility} aboard the ${inv.platform} · ${inv.gravityCondition}` +
      (inv.status ? ` · status: ${inv.status.toLowerCase()}` : ""),
  );
  if (inv.keyFindings.length > 0) {
    lines.push(`- **What the researchers found:** ${inv.keyFindings.join(" ")}`);
  }
  lines.push(`- **In short:** ${trimSentences(inv.summary)}`);
  const url = inv.sourceUrl ?? inv.ntrsUrl;
  if (url) lines.push(`- **Verified source:** ${url}${inv.doi ? ` · DOI: ${inv.doi}` : ""}`);
  return lines.join("\n");
}

export function offlineAnswer(message: string, top: InvestigationDTO[]): string {
  if (top.length === 0) {
    return (
      "**I could not match any verified records to that question.**\n\n" +
      "Try asking about one of the platform's experiments by name — for example [FLEX], [BASS], [SAFFIRE-I] or [DAFT] — or browse the NASA Research Explorer to see the full verified corpus."
    );
  }

  const focused = top.filter((r): r is InvestigationDTO => Boolean(r)).slice(0, 3);
  if (focused.length === 0) {
    return (
      "**I could not match any verified records to that question.**\n\n" +
      "Try asking about one of the platform's experiments by name — for example [FLEX], [BASS], [SAFFIRE-I] or [DAFT] — or browse the NASA Research Explorer to see the full verified corpus."
    );
  }
  const intro =
    focused.length === 1
      ? `Here is what the verified NASA records teach us about that — this is the **${focused[0].code}** investigation.`
      : `Here is what the verified NASA records teach us about that. The closest investigations are **${focused
          .map((r) => r.code)
          .join(", ")}** — I'll walk you through each one.`;

  const lines: string[] = [intro, ""];
  focused.forEach((inv) => {
    lines.push(lessonBlock(inv));
    lines.push("");
  });

  lines.push(
    "_Every statement above is taken directly from the verified records cited here — nothing is added beyond them. Ask a follow-up below, or open any record in the NASA Research Explorer for the full story._",
  );
  return lines.join("\n").trim();
}

export function heuristicFollowUps(top: InvestigationDTO[]): string[] {
  const a = top[0];
  const b = top[1] ?? top[0];
  if (!a) return [];
  const out = [
    `What did the ${a.code} investigation measure?`,
    `What did researchers learn from ${a.code} aboard the ${a.platform}?`,
  ];
  if (b && b.code !== a.code) out.push(`Compare ${a.code} and ${b.code} — what differs in their approach?`);
  return out.slice(0, 3);
}
