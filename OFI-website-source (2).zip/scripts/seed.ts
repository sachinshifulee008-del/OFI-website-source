/**
 * OFI research corpus seed — CLI entry point.
 *
 * The record data lives in src/lib/ofi/seedData.ts so the server can also
 * auto-seed an empty database at startup (see src/instrumentation.ts).
 * Run manually: bun scripts/seed.ts
 */
import { seedDatabase } from "../src/lib/ofi/seedRunner";

seedDatabase()
  .then((n) => console.log(`Seeded ${n} investigations.`))
  .catch((e) => {
    console.error(e);
    process.exit(1);
  });
