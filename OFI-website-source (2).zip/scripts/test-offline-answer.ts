// Verify the offline tutor answer reads like a real lesson using live corpus DTOs.
import { offlineAnswer, heuristicFollowUps } from "../src/lib/ofi/offlineAnswer";
import type { InvestigationDTO } from "../src/lib/ofi/types";

async function main() {
  const res = await fetch("http://localhost:3000/api/investigations?pageSize=50");
  const data = (await res.json()) as { items: InvestigationDTO[] };
  const corpus = data.items;
  console.log("corpus size from API:", corpus.length, "| codes:", corpus.map((c) => c.code).join(", "));

  console.log("=== Query: SAFFIRE ===");
  const top = [corpus.find((c) => c.code === "SAFFIRE-I")!, corpus.find((c) => c.code === "BASS")!];
  console.log(offlineAnswer("What did SAFFIRE study?", top));
  console.log("\n=== follow-ups ===", heuristicFollowUps(top));
  console.log("\n=== Query: no match ===");
  console.log(offlineAnswer("asdf", []));
}

main();
