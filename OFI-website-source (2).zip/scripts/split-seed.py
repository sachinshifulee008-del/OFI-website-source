import re

src = open('scripts/seed.ts').read()

header_end = src.index('type SeedSource = {')
corpus_start = src.index('const CORPUS: SeedRecord[] = [')
corpus_end = src.index('];', corpus_start) + 2
main_start = src.index('async function main() {')

header_comment = src[:header_end].strip()
types_and_corpus = src[header_end:corpus_end]
main_body = src[main_start:]

# --- seedData.ts: types + records, no Prisma import ---
data_ts = header_comment.replace('import { PrismaClient } from "@prisma/client";\n', '').rstrip()
data_ts += '\n\n' + types_and_corpus.replace('const CORPUS: SeedRecord[] = [', 'export const SEED_RECORDS: SeedRecord[] = [').rstrip() + '\n'
open('src/lib/ofi/seedData.ts', 'w').write(data_ts)

runner = '''import { db } from "@/lib/db";
import { SEED_RECORDS } from "./seedData";

export async function seedDatabase(): Promise<number> {
  await db.source.deleteMany();
  await db.investigation.deleteMany();

  for (const r of SEED_RECORDS) {
    const rec = await db.investigation.create({
      data: {
        code: r.code,
        name: r.name,
        category: r.category,
        objective: r.objective,
        summary: r.summary,
        gravityCondition: r.gravityCondition,
        facility: r.facility,
        platform: r.platform,
        status: r.status,
        launchYear: r.launchYear ?? null,
        delivery: r.delivery ?? null,
        researchAreas: JSON.stringify(r.researchAreas),
        fuelsMaterials: JSON.stringify(r.fuelsMaterials),
        keyFindings: JSON.stringify(r.keyFindings),
        variables: JSON.stringify(r.variables),
        doi: r.doi ?? null,
        sourceUrl: r.sourceUrl ?? null,
        ntrsUrl: r.ntrsUrl ?? null,
        datasetAvailable: r.datasetAvailable,
        measurementData: r.measurementData,
      },
    });
    for (const s of r.sources) {
      await db.source.create({
        data: {
          investigationId: rec.id,
          title: s.title,
          authors: s.authors,
          year: s.year ?? null,
          venue: s.venue,
          kind: s.kind,
          doi: s.doi ?? null,
          url: s.url ?? null,
        },
      });
    }
  }
  return SEED_RECORDS.length;
}

// Self-healing: if the database boots empty (fresh provisioning, recycled
// sandbox, or a schema-only db push), restore the verified corpus at startup.
export async function seedIfEmpty(): Promise<boolean> {
  const count = await db.investigation.count();
  if (count > 0) return false;
  const seeded = await seedDatabase();
  console.log(`[ofi] empty database detected at startup — seeded ${seeded} investigations.`);
  return true;
}
'''
open('src/lib/ofi/seedRunner.ts', 'w').write(runner)

cli = '''/**
 * OFI research corpus seed — CLI entry point.
 *
 * The record data lives in src/lib/ofi/seedData.ts so the server can also
 * auto-seed an empty database at startup (see src/instrumentation.ts).
 * Run manually: bun scripts/seed.ts
 */
import { seedDatabase } from "../src/lib/ofi/seedRunner";

seedDatabase()
  .then((n) => console.log(`Seeded ${n} investigations.`))
  .catch((e) => {
    console.error(e);
    process.exit(1);
  });
'''
open('scripts/seed.ts', 'w').write(cli)
print('split done: seedData.ts', len(data_ts.splitlines()), 'lines; runner 60 lines')
